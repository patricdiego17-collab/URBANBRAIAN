from pathlib import Path
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor, Color, white
from reportlab.lib.utils import ImageReader
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfbase import pdfmetrics
from PIL import Image
import textwrap

ROOT=Path('.')
A=ROOT/'assets'
D=ROOT/'datasheets'
D.mkdir(exist_ok=True)
W,H=960,540  # 16:9 presentation canvas

try:
    pdfmetrics.registerFont(TTFont('UB','/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'))
    pdfmetrics.registerFont(TTFont('UBB','/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'))
except Exception:
    pass

NAVY=HexColor('#06121F'); NAVY2=HexColor('#0A1E30'); NAVY3=HexColor('#102A40')
BLUE=HexColor('#0A8EF0'); CYAN=HexColor('#20CBE2'); TEXT=HexColor('#0C2438')
MUTED=HexColor('#657B8F'); PALE=HexColor('#F3F7FA'); LINE=HexColor('#D7E3EB')
GREEN=HexColor('#22AE7B'); WHITE=white

mods={
'cco-seguranca':{
 'title':'CCO e Segurança','subtitle':'Inteligência operacional para monitorar, correlacionar, despachar e auditar em uma mesma visão.','image':'cco-display.jpg',
 'overview':['Integra videomonitoramento, visão computacional, Muralha LPR/OCR, reconhecimento facial, CAD, GIS, GED, frotas, telemetria e BI em uma operação coordenada.','A lógica operacional conecta detecção, contexto territorial, resposta, evidências e indicadores, reduzindo a fragmentação entre sistemas e equipes.'],
 'capabilities':['Videomonitoramento ao vivo, playback, mosaicos, rondas e investigação forense.','Analíticos de vídeo para eventos como intrusão, fogo, uso de EPI e outras regras configuradas.','Muralha Inteligente com leitura de placas, listas de interesse, fatos, correlações e alertas.','Reconhecimento facial para pesquisa e alertas dentro dos requisitos e políticas definidos no projeto.','Central de Despacho para triagem, prioridade, missão, equipe, viatura, acompanhamento e encerramento.','Mapa GIS com câmeras, viaturas, ocorrências, sensores, entidades e histórico territorial.','GED com documentos, contratos, evidências e contexto associado às ocorrências.','Dashboards e BI para leitura executiva e operacional.'],
 'components':[('VMS e vídeo','Câmeras, mosaicos, gravação, playback, exportação e timeline de evidências.'),('Muralha','LPR/OCR, listas, regras, pesquisas, passagens e correlações.'),('CAD','Atendimento, triagem, prioridade, despacho e acompanhamento de recursos.'),('GIS','Mapa operacional com ativos, eventos, equipes e contexto territorial.'),('Investigação','Pesquisa histórica, evidências, documentos e correlação entre eventos.'),('Operação móvel','Viaturas, agentes, missões, localização e atualização de ocorrências.')],
 'integrations':['VMS / CFTV','LPR / OCR','Reconhecimento facial','CAD','GIS','GED + IA','Frotas','Telemetria','BI','APIs'],
 'flow':[('Detectar','Receber vídeo, alerta analítico, leitura de placa, sensor ou solicitação.'),('Contextualizar','Relacionar mapa, histórico, pessoas, veículos, câmeras, documentos e criticidade.'),('Coordenar','Aplicar procedimento, priorizar e despachar o recurso adequado.'),('Executar','Acompanhar missão, evidências, ações e atualização da ocorrência.'),('Auditar','Consolidar histórico, evidências, indicadores e trilha operacional.')],
 'specs':[('Arquitetura','Modular, integrável e expansível por etapas.'),('Operação','Web e mobilidade conforme módulos e equipamentos implantados.'),('Segurança','Perfis, permissões granulares, isolamento organizacional e auditoria.'),('Escala','Dimensionamento conforme câmeras, retenção, analíticos, usuários e integrações.'),('Integração','APIs e conectores definidos conforme sistemas legados e infraestrutura disponível.'),('Evidências','Vídeos, imagens, documentos, histórico, localização e registros vinculados ao contexto operacional.')],
 'deployment':['Mapear sistemas, câmeras, centrais e integrações existentes.','Definir perfis de operação, procedimentos, prioridades e regras de alerta.','Planejar capacidade de processamento, retenção, rede e armazenamento.','Implantar por ondas, validando operação, treinamento e indicadores.'],
},
'educacao-escolas':{
 'title':'Educação e Escolas','subtitle':'Frequência automatizada, proteção escolar, comunicação com famílias e inteligência para permanência do aluno.','image':'educacao-display.jpg',
 'overview':['Integra reconhecimento facial, controle de acesso, frequência, responsáveis, notificações, ocorrências, transporte escolar e dados territoriais em uma visão de rede.','A escola deixa de depender apenas de rotinas manuais e passa a produzir eventos rastreáveis de presença, acesso e segurança.'],
 'capabilities':['Registro automático de presença por reconhecimento facial, conforme regras e infraestrutura definidas.','Identificação de alunos, responsáveis e pessoas previamente autorizadas.','Validação do vínculo entre aluno e responsável no acesso e retirada.','Notificações de entrada, ausência e eventos relevantes por canais configurados.','Indicadores para acompanhamento de frequência e apoio à prevenção da evasão.','Proteção perimetral e integração de ocorrências escolares com o centro de operações.','Integração com transporte escolar, saúde, censo e dados georreferenciados quando previstos.','Relatórios por aluno, unidade, período, evento e situação operacional.'],
 'components':[('Presença facial','Captura, identificação e registro de presença com histórico temporal.'),('Controle de acesso','Catracas ou fluxo aberto, responsáveis autorizados e regras por unidade.'),('Família conectada','Notificações e comunicação de presença, ausência e eventos relevantes.'),('Segurança escolar','Alertas, ocorrências, proteção perimetral e integração com CCO.'),('Visão territorial','Unidades, alunos, transporte, indicadores e eventos em GIS.'),('Gestão de rede','Relatórios, acompanhamento por unidade e indicadores consolidados.')],
 'integrations':['Biometria facial','Controle de acesso','Notificações','Transporte escolar','Ocorrências','GIS','Relatórios','APIs'],
 'flow':[('Identificar','Reconhecer aluno, responsável, colaborador ou visitante autorizado.'),('Validar','Aplicar vínculo, permissão, horário, unidade e regras de acesso.'),('Registrar','Gravar presença, entrada, saída, ausência ou exceção.'),('Comunicar','Notificar responsáveis e equipes conforme o evento.'),('Acompanhar','Consolidar frequência, alertas, ocorrências e indicadores da rede.')],
 'specs':[('Identificação','Reconhecimento facial e demais credenciais previstas no projeto.'),('Acesso','Catracas, fluxo aberto ou combinação conforme desenho de cada unidade.'),('Registros','Presença, entradas, saídas, alertas, eventos e histórico consultável.'),('Comunicação','Notificações e canais digitais conforme configuração e disponibilidade.'),('Integração','Transporte escolar, CCO, GIS e sistemas educacionais conforme escopo.'),('Governança','Perfis, permissões, rastreabilidade de ações e proteção de dados conforme política do projeto.')],
 'deployment':['Definir unidades, fluxos de acesso e infraestrutura de captura.','Preparar cadastros e vínculos entre alunos e responsáveis.','Configurar regras de presença, exceções e comunicação.','Executar piloto, aferir operação e expandir por ondas para a rede.'],
},
'transporte-publico':{
 'title':'Mobilidade e Transporte','subtitle':'Bilhetagem facial, transporte escolar conectado, telemetria e inteligência sobre a jornada.','image':'transporte-display.jpg',
 'overview':['A vertical reúne autenticação facial 1:N para transporte público e gestão conectada do transporte escolar, com vídeo, RFID, GPS, telemetria e recursos de segurança do condutor.','O objetivo é registrar a jornada do embarque ao desembarque e relacionar passageiro, aluno, veículo, rota, condutor e eventos em uma operação auditável.'],
 'capabilities':['Reconhecimento facial 1:N como credencial de mobilidade no transporte público.','Embarque touchless com menor dependência de cartões e mídias físicas.','Cadastro e recarga digital pelo aplicativo, conforme desenho da solução.','Referência de acurácia antifraude superior a 99,5% no material fornecido para o projeto.','Possibilidade de reaproveitamento de câmeras existentes quando tecnicamente compatíveis.','RFID para registro de embarque e desembarque de alunos no transporte escolar.','Câmeras internas, laterais e frontal conforme arquitetura embarcada.','GPS, rotas, geofences, histórico, telemetria e eventos de condução.','ADAS e DMS conforme equipamentos integrados e escopo.','Relatórios por passageiro, aluno, veículo, condutor, rota, evento e período.'],
 'components':[('Bilhetagem facial','Identificação 1:N, credencial biométrica e embarque touchless.'),('Antifraude','Validação biométrica e análise de uso de benefícios conforme regras implantadas.'),('Transporte escolar','RFID, câmeras, rotas, horários, paradas e histórico por aluno.'),('Vídeo embarcado','Câmeras internas, laterais e frontal com eventos e playback conforme arquitetura.'),('Condutor','ADAS, DMS e sensor etílico conforme equipamentos e configuração.'),('Telemetria','GPS, velocidade, consumo, diagnóstico, geofences e comportamento operacional.')],
 'integrations':['Biometria 1:N','Validador embarcado','Aplicativo','RFID','Vídeo / MDVR','GPS / GIS','ADAS / DMS','Telemetria','BI','APIs'],
 'flow':[('Identificar','Reconhecer passageiro/aluno ou associar credencial e veículo.'),('Validar','Aplicar regras de acesso, benefício, vínculo, rota e operação.'),('Registrar','Gravar embarque, desembarque, posição, vídeo e telemetria.'),('Monitorar','Detectar desvios, eventos de condução, exceções ou possível fraude.'),('Analisar','Consolidar indicadores e relatórios por pessoa, veículo, rota e período.')],
 'specs':[('Transporte público','Reconhecimento facial 1:N, embarque touchless e recarga digital conforme solução.'),('Antifraude','Referência superior a 99,5% no material fornecido para o projeto.'),('Infraestrutura','Reaproveitamento de câmeras condicionado à compatibilidade técnica.'),('Transporte escolar','RFID, cadastro de veículo, motorista, aluno, rota e dispositivos.'),('Telemetria','GPS, velocidade, consumo, diagnóstico, comportamento, rotas e geofences.'),('Implantação','Faseada conforme frota, conectividade, validadores, câmeras e integrações existentes.')],
 'deployment':['Inventariar frota, validadores, câmeras, conectividade e sistemas atuais.','Definir jornada biométrica, regras de benefício e fluxos de exceção.','Configurar rotas, veículos, condutores, alunos e dispositivos.','Executar piloto controlado e ampliar conforme indicadores operacionais.'],
},
'saude-digital':{
 'title':'Saúde Digital','subtitle':'UBS digital, prontuário, telemedicina, biomonitores e inteligência territorial conectados à gestão da rede.','image':'saude-display.jpg',
 'overview':['Digitaliza fluxos da atenção primária e conecta prontuário, agenda, teleatendimento, teleinterconsulta, dispositivos biomédicos e visão territorial.','A integração bidirecional com e-SUS AB e demais interfaces previstas no projeto busca reduzir duplicidade de registro e ampliar a continuidade assistencial.'],
 'capabilities':['Fluxos assistenciais digitais na UBS e registro unificado da jornada do paciente.','Integração bidirecional nativa com e-SUS AB conforme escopo técnico informado.','Integrações adicionais, como RNDS, condicionadas ao escopo e interfaces disponíveis.','Agendamento, vagas, encaixes, filas e painéis de chamada.','Teleconsulta, teleinterconsulta e telediagnóstico.','Consultórios virtuais com biomonitores IoT quando previstos.','Recursos como ECG e estetoscópio digital no cenário de teleinterconsulta.','Vigilância epidemiológica e georreferenciamento de endemias.','Painéis, indicadores, mapas e relatórios para gestão da rede.'],
 'components':[('UBS digital','Cadastro, agenda, atendimento, registro e acompanhamento em fluxo digital.'),('Prontuário','Histórico clínico e assistencial com acesso conforme perfis e permissões.'),('Telemedicina','Teleconsulta, teleinterconsulta e telediagnóstico.'),('Biomonitores','Dispositivos IoT e sinais clínicos conforme equipamentos previstos.'),('Saúde territorial','Mapeamento de endemias, agentes, focos e indicadores geográficos.'),('Gestão da rede','Filas, vagas, indicadores, painéis e relatórios operacionais.')],
 'integrations':['Prontuário','e-SUS AB','RNDS conforme escopo','Telemedicina','Biomonitores IoT','GIS','Painéis','APIs'],
 'flow':[('Registrar','Cadastrar paciente, agenda, atendimento e contexto clínico.'),('Atender','Executar jornada presencial ou remota e registrar produção assistencial.'),('Conectar','Sincronizar sistemas e dispositivos previstos no escopo.'),('Monitorar','Acompanhar sinais, filas, vagas, produção e situação territorial.'),('Gerir','Transformar dados assistenciais e operacionais em indicadores para decisão.')],
 'specs':[('Prontuário','Histórico clínico, registros assistenciais, agenda e documentação relacionada.'),('Integração','e-SUS AB bidirecional e demais interfaces conforme escopo e disponibilidade.'),('Telemedicina','Teleconsulta, teleinterconsulta e telediagnóstico.'),('IoT clínico','Biomonitores e dispositivos biomédicos conforme equipamentos homologados no projeto.'),('Território','GIS para vigilância, endemias e leitura espacial de indicadores.'),('Governança','Perfis, auditoria, segurança, disponibilidade e requisitos de proteção de dados definidos no projeto.')],
 'deployment':['Mapear unidades, jornadas assistenciais e sistemas existentes.','Definir integrações, perfis, cadastros e requisitos de conectividade.','Implantar fluxos digitais e telemedicina por ondas controladas.','Aferir uso, produção, indicadores e ampliar o escopo conforme maturidade da rede.'],
},
'telegestao-defesa-civil':{
 'title':'Telegestão e Defesa Civil','subtitle':'Iluminação, sensores, clima, risco, sirenes, vistorias e equipes coordenados pelo território.','image':'defesa-display.jpg',
 'overview':['Conecta telegestão da iluminação pública, monitoramento ambiental, áreas de risco, sirenes e operação de campo em um mesmo ambiente georreferenciado.','A plataforma apoia prevenção, manutenção, inspeção e resposta, mantendo histórico de ativos, leituras, acionamentos e providências.'],
 'capabilities':['Cadastro de gateways, controladores, grupos, postes e locais georreferenciados.','Comandos remotos de ligar, desligar, dimerizar, consultar informações e reconectar.','Agendamentos com horários, vigência e aplicação por unidade ou grupo.','Telemetria elétrica, consumo e indicadores para manutenção preventiva e preditiva.','Áreas de risco desenhadas por polígonos geográficos.','Cadastro de moradias, moradores e composição familiar em áreas vulneráveis quando previsto.','Sensores pluviométricos e estações meteorológicas em mapa.','Sirenes com acionamento conforme protocolos da operação implantada.','Vistorias, ordens de serviço e execução de campo offline-first.','Integração com central de despacho, equipes, histórico e relatórios.'],
 'components':[('Iluminação IoT','Gateways, controladores, grupos, comandos, agendamentos e telemetria.'),('Gestão energética','Consumo, status, falhas e indicadores para manutenção.'),('Território de risco','Polígonos, moradias, moradores, pontos críticos e histórico.'),('Sensores e clima','Pluviometria, estações meteorológicas e leitura preventiva.'),('Sirenes','Acionamento e protocolos de resposta conforme arquitetura implantada.'),('Campo offline-first','Vistorias, ordens, fotos, formulários e sincronização posterior.')],
 'integrations':['IoT','Iluminação','MQTT conforme arquitetura','Pluviometria','Meteorologia','Sirenes','GIS','Ordens de serviço','CAD','APIs'],
 'flow':[('Monitorar','Receber telemetria de iluminação, sensores e condições territoriais.'),('Avaliar','Relacionar falha ou risco ao mapa, histórico e criticidade.'),('Acionar','Executar comando, gerar alerta, sirene, ordem ou despacho de equipe.'),('Executar','Realizar vistoria, manutenção ou resposta em campo, inclusive offline.'),('Acompanhar','Consolidar histórico, evidências, indicadores e resultados preventivos.')],
 'specs':[('Iluminação','Gateways, controladores, grupos, telemetria, comandos e agendamentos.'),('Território','Áreas de risco, moradias, sensores, sirenes e estações em GIS.'),('Campo','Ordens, vistorias, formulários, fotos e operação offline-first.'),('Resposta','Integração com central de despacho e equipes.'),('Relatórios','Histórico, exceções, inspeções, consumo e indicadores gerenciais.'),('Implantação','Dimensionamento conforme pontos de luz, cobertura de comunicação, sensores, áreas de risco e procedimentos locais.')],
 'deployment':['Inventariar ativos de iluminação, rede, sensores e áreas de risco.','Definir cobertura de comunicação, gateways, grupos e protocolos.','Configurar regras de alerta, sirenes, vistorias e procedimentos de resposta.','Implantar por regiões e validar telemetria, campo, sincronização e indicadores.'],
},
}

def draw_logo(c,x=48,y=490,w=150):
    p=A/'urban-brain-wordmark.jpg'
    if p.exists():
        im=Image.open(p); iw,ih=im.size; h=w*ih/iw
        c.drawImage(ImageReader(im),x,y-h,w,h,mask='auto')

def cover_image(c,path):
    im=Image.open(path).convert('RGB'); iw,ih=im.size
    s=max(W/iw,H/ih); nw,nh=iw*s,ih*s
    c.drawImage(ImageReader(im),(W-nw)/2,(H-nh)/2,nw,nh)

def wrap_lines(c,text,font,size,maxw):
    words=text.split(); lines=[]; cur=''
    for word in words:
        nxt=(cur+' '+word).strip()
        if c.stringWidth(nxt,font,size)<=maxw: cur=nxt
        else:
            if cur: lines.append(cur)
            cur=word
    if cur: lines.append(cur)
    return lines

def para(c,text,x,y,maxw,size=15,leading=21,font='UB',color=MUTED,max_lines=None):
    c.setFont(font,size); c.setFillColor(color)
    lines=wrap_lines(c,text,font,size,maxw)
    if max_lines: lines=lines[:max_lines]
    for line in lines:
        c.drawString(x,y,line); y-=leading
    return y

def title(c,kicker,head,sub=None,dark=False):
    col=WHITE if dark else TEXT; mut=HexColor('#A8BDCF') if dark else MUTED
    c.setFillColor(CYAN if dark else BLUE); c.setFont('UBB',11); c.drawString(54,478,kicker.upper())
    c.setFillColor(col); c.setFont('UBB',30)
    y=447
    for line in wrap_lines(c,head,'UBB',30,820)[:2]: c.drawString(54,y,line); y-=36
    if sub: para(c,sub,54,y-3,820,13,18,'UB',mut,3)

def footer(c,module,dark=False):
    c.setStrokeColor(HexColor('#28455E') if dark else LINE); c.line(54,32,906,32)
    c.setFillColor(HexColor('#90A8BA') if dark else MUTED); c.setFont('UB',8)
    c.drawString(54,16,'URBAN BRAIN')
    c.drawRightString(906,16,module)

def card(c,x,y,w,h,head,body,dark=False):
    fill=NAVY2 if dark else WHITE; stroke=HexColor('#264A64') if dark else LINE
    c.setFillColor(fill); c.setStrokeColor(stroke); c.roundRect(x,y,w,h,10,fill=1,stroke=1)
    c.setFillColor(CYAN if dark else BLUE); c.setFont('UBB',12); c.drawString(x+16,y+h-26,head)
    para(c,body,x+16,y+h-47,w-32,10.5,15,'UB',HexColor('#B8CBDA') if dark else MUTED,5)

def chip(c,text,x,y,dark=False):
    font='UBB'; size=8; pad=9; w=c.stringWidth(text,font,size)+pad*2
    c.setFillColor(HexColor('#0C2A40') if dark else HexColor('#EAF6FD')); c.setStrokeColor(HexColor('#2B5975') if dark else HexColor('#B9DDEC'))
    c.roundRect(x,y,w,22,5,fill=1,stroke=1); c.setFillColor(CYAN if dark else HexColor('#0878C7')); c.setFont(font,size); c.drawCentredString(x+w/2,y+7,text)
    return w

def slide_cover(c,m):
    cover_image(c,A/m['image'])
    c.setFillColor(Color(0.01,0.035,0.06,.76)); c.rect(0,0,W,H,fill=1,stroke=0)
    c.setFillColor(Color(0.02,0.08,0.13,.85)); c.roundRect(42,58,570,310,18,fill=1,stroke=0)
    draw_logo(c,60,500,145)
    c.setFillColor(CYAN); c.setFont('UBB',11); c.drawString(62,336,'APRESENTAÇÃO TÉCNICA')
    c.setFillColor(WHITE); c.setFont('UBB',40); y=295
    for line in wrap_lines(c,m['title'],'UBB',40,500)[:2]: c.drawString(62,y,line); y-=46
    para(c,m['subtitle'],62,y-6,500,14,20,'UB',HexColor('#D8E8F2'),4)
    c.setFillColor(HexColor('#9CC2D8')); c.setFont('UB',9); c.drawString(62,82,'Inteligência que conecta cidades. Gestão que transforma.')

def slide_overview(c,m):
    c.setFillColor(PALE); c.rect(0,0,W,H,fill=1,stroke=0); title(c,'Visão geral',m['title'],m['subtitle'])
    x=54; y=360
    for p in m['overview']:
        c.setFillColor(BLUE); c.circle(x+5,y+6,4,fill=1,stroke=0)
        y=para(c,p,x+20,y,500,14,20,'UB',TEXT,5)-18
    im=Image.open(A/m['image']); iw,ih=im.size; s=max(310/iw,230/ih); nw,nh=iw*s,ih*s
    c.saveState(); c.roundRect(632,102,274,258,14,fill=0,stroke=0); c.clipPath(c.beginPath(),stroke=0,fill=0) if False else None; c.restoreState()
    c.drawImage(ImageReader(im),632+(274-nw)/2,102+(258-nh)/2,nw,nh,mask='auto')
    c.setStrokeColor(LINE); c.roundRect(632,102,274,258,14,fill=0,stroke=1); footer(c,m['title'])

def slide_capabilities(c,m):
    c.setFillColor(WHITE); c.rect(0,0,W,H,fill=1,stroke=0); title(c,'Capacidades','O que a solução entrega na operação')
    items=m['capabilities']; cols=2; rows=(len(items)+1)//2; cw=410; x0=54; x1=496; y=365
    for i,it in enumerate(items):
        col=0 if i<rows else 1; idx=i if col==0 else i-rows; x=x0 if col==0 else x1; yy=y-idx*78
        c.setFillColor(HexColor('#E9F6FD')); c.roundRect(x,yy-48,cw,62,8,fill=1,stroke=0)
        c.setFillColor(BLUE); c.circle(x+17,yy-17,4,fill=1,stroke=0)
        para(c,it,x+30,yy-7,cw-43,10.2,14,'UB',TEXT,4)
    footer(c,m['title'])

def slide_components(c,m):
    c.setFillColor(NAVY); c.rect(0,0,W,H,fill=1,stroke=0); title(c,'Componentes funcionais','Blocos que sustentam a solução',dark=True)
    items=m['components']; positions=[(54,265),(352,265),(650,265),(54,110),(352,110),(650,110)]
    for (h,b),(x,y) in zip(items,positions): card(c,x,y,256,128,h,b,True)
    footer(c,m['title'],True)

def slide_integrations(c,m):
    c.setFillColor(PALE); c.rect(0,0,W,H,fill=1,stroke=0); title(c,'Arquitetura e integração','Conectado às camadas transversais do URBAN BRAIN')
    layers=[('Experiência','Web, aplicativos e operação em campo'),('Operação','CAD, VMS, mapas, alertas e fluxos'),('Dados','Histórico, GED, BI, relatórios e evidências'),('Integração','APIs, conectores e sistemas legados'),('Governança','Perfis, permissões, multi-tenant e auditoria')]
    y=340
    for h,b in layers:
        c.setFillColor(WHITE); c.setStrokeColor(LINE); c.roundRect(54,y,410,55,8,fill=1,stroke=1)
        c.setFillColor(BLUE); c.setFont('UBB',10); c.drawString(70,y+32,h)
        para(c,b,70,y+16,370,9.3,12,'UB',MUTED,2); y-=63
    c.setFillColor(NAVY2); c.roundRect(500,105,406,290,14,fill=1,stroke=0)
    c.setFillColor(CYAN); c.setFont('UBB',12); c.drawString(524,362,'INTEGRAÇÕES E CAMADAS')
    xx=524; yy=320
    for t in m['integrations']:
        w=chip(c,t,xx,yy,True)
        if xx+w>865:
            xx=524; yy-=36; w=chip(c,t,xx,yy,True)
        xx+=w+8
    footer(c,m['title'])

def slide_flow(c,m):
    c.setFillColor(WHITE); c.rect(0,0,W,H,fill=1,stroke=0); title(c,'Fluxo operacional','Uma jornada clara, rastreável e auditável')
    items=m['flow']; gap=10; cw=(852-gap*(len(items)-1))/len(items); x=54; y=180
    for head,body in items:
        c.setFillColor(HexColor('#F2F8FC')); c.setStrokeColor(LINE); c.roundRect(x,y,cw,190,10,fill=1,stroke=1)
        c.setFillColor(BLUE); c.setFont('UBB',14); c.drawCentredString(x+cw/2,y+144,head)
        para(c,body,x+15,y+112,cw-30,9.5,14,'UB',MUTED,6)
        x+=cw+gap
    footer(c,m['title'])

def slide_specs(c,m):
    c.setFillColor(PALE); c.rect(0,0,W,H,fill=1,stroke=0); title(c,'Especificações consolidadas','Parâmetros para orientar avaliação técnica e implantação')
    y=364
    for head,body in m['specs']:
        c.setFillColor(WHITE); c.setStrokeColor(LINE); c.roundRect(54,y-48,852,58,8,fill=1,stroke=1)
        c.setFillColor(HexColor('#EAF6FD')); c.roundRect(54,y-48,190,58,8,fill=1,stroke=0)
        c.setFillColor(BLUE); c.setFont('UBB',10); c.drawString(70,y-18,head)
        para(c,body,260,y-12,625,10,14,'UB',TEXT,3); y-=64
    footer(c,m['title'])

def slide_deployment(c,m):
    c.setFillColor(NAVY); c.rect(0,0,W,H,fill=1,stroke=0); title(c,'Implantação','Diretrizes para uma adoção controlada e escalável',dark=True)
    y=342
    for head,body in [('Preparação',m['deployment'][0]),('Configuração',m['deployment'][1]),('Implantação',m['deployment'][2]),('Evolução',m['deployment'][3])]:
        c.setFillColor(NAVY2); c.setStrokeColor(HexColor('#274A64')); c.roundRect(54,y-65,410,75,9,fill=1,stroke=1)
        c.setFillColor(CYAN); c.setFont('UBB',11); c.drawString(70,y-28,head)
        para(c,body,70,y-45,375,9.8,13,'UB',HexColor('#BCD0DF'),3)
        y-=87
    c.setFillColor(NAVY2); c.setStrokeColor(HexColor('#274A64')); c.roundRect(500,112,406,240,12,fill=1,stroke=1)
    c.setFillColor(WHITE); c.setFont('UBB',14); c.drawString(524,316,'Princípios de projeto')
    principles=['Escopo e dimensionamento confirmados no projeto executivo.','Integrações condicionadas às interfaces e permissões disponíveis.','Implantação modular para reduzir risco operacional.','Perfis, auditoria e governança definidos desde a configuração inicial.','Treinamento e indicadores de adoção acompanhando cada etapa.']
    yy=280
    for p in principles:
        c.setFillColor(CYAN); c.circle(529,yy+4,3,fill=1,stroke=0); yy=para(c,p,540,yy,340,9.5,13,'UB',HexColor('#BCD0DF'),3)-12
    footer(c,m['title'],True)

def slide_close(c,m):
    c.setFillColor(NAVY); c.rect(0,0,W,H,fill=1,stroke=0)
    draw_logo(c,55,490,160); c.setFillColor(CYAN); c.setFont('UBB',11); c.drawString(56,378,'PRÓXIMO PASSO')
    c.setFillColor(WHITE); c.setFont('UBB',36); y=336
    for line in wrap_lines(c,'Veja a solução aplicada ao seu cenário operacional.','UBB',36,690)[:2]: c.drawString(56,y,line); y-=44
    para(c,'Solicite uma demonstração técnica para percorrer arquitetura, integrações, fluxos e parâmetros de implantação do '+m['title']+'.',56,y-6,680,14,20,'UB',HexColor('#C5D8E6'),4)
    c.setFillColor(BLUE); c.roundRect(56,108,330,54,8,fill=1,stroke=0); c.setFillColor(WHITE); c.setFont('UBB',12); c.drawString(78,129,'Solicitar Demonstração')
    c.setFillColor(HexColor('#9DB7CA')); c.setFont('UB',10); c.drawString(56,78,'WhatsApp +55 11 98666-2944')
    footer(c,m['title'],True)

for slug,m in mods.items():
    p=D/(slug+'.pdf'); c=canvas.Canvas(str(p),pagesize=(W,H))
    for fn in [slide_cover,slide_overview,slide_capabilities,slide_components,slide_integrations,slide_flow,slide_specs,slide_deployment,slide_close]:
        fn(c,m); c.showPage()
    c.save(); print(p, 'created')
