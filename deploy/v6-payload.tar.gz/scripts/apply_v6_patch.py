from pathlib import Path
import re

# Home page: remove visual numbering from content topics and update PDF language.
p=Path('index.html')
s=p.read_text(encoding='utf-8')
# Remove numbered badges in ecosystem and architecture sequences.
s=re.sub(r'(<div class="story-list">.*?)<article><span>\d{2}</span><div>', lambda m: m.group(1)+'<article><div>', s, count=1, flags=re.S)
# Remaining story-list items.
s=re.sub(r'<article><span>\d{2}</span><div>', '<article><div>', s)
s=re.sub(r'<article><span>\d{2}</span><strong>', '<article><strong>', s)
s=re.sub(r'<div><span>\d{2}</span><strong>', '<div><strong>', s)
s=re.sub(r'<summary><span>\d{2}</span><strong>', '<summary><strong>', s)
# Terminology for module collateral.
s=s.replace('Cada vertical possui página técnica dedicada e PDF próprio, com capacidades, fluxo operacional, integrações e parâmetros de implantação.',
            'Cada vertical possui página técnica dedicada e uma apresentação técnica própria, com capacidades, componentes, integrações, fluxo operacional, especificações e implantação.')
s=s.replace('Ver Datasheet <span aria-hidden="true">↗</span>', 'Conhecer solução <span aria-hidden="true">↗</span>')
s=s.replace('<span>Baixar PDF</span>', '<span>Apresentação técnica</span>')
s=s.replace('Manual técnico aprofundado da plataforma e datasheets completos por módulo para avaliação funcional, arquitetura, especificação e implantação.',
            'Manual técnico aprofundado da plataforma e apresentações técnicas por módulo para avaliação funcional, arquitetura, especificação, implantação e reuniões executivas.')
s=s.replace('<b>PDF ↘</b>', '<b>APRESENTAÇÃO ↘</b>')
p.write_text(s,encoding='utf-8')

# Module pages: remove numbered flow badges and change collateral language.
for p in Path('modulos').glob('*.html'):
    t=p.read_text(encoding='utf-8')
    t=re.sub(r'<article><span>\d{2}</span><div>', '<article><div>', t)
    t=t.replace('Baixar Datasheet Técnico (PDF)', 'Baixar Apresentação Técnica (PDF)')
    t=t.replace('Baixar Datasheet (PDF)', 'Baixar Apresentação Técnica (PDF)')
    t=t.replace('Leve o documento técnico desta solução para sua reunião.', 'Leve a apresentação técnica desta solução para sua reunião.')
    t=t.replace('PDF aprofundado com visão geral, capacidades, integrações, fluxo operacional, especificações e pontos de implantação.',
                'Apresentação horizontal com visão geral, capacidades, componentes, integrações, fluxo operacional, especificações e diretrizes de implantação.')
    t=t.replace('>Datasheet<', '>Apresentação<')
    p.write_text(t,encoding='utf-8')

# CSS: show the entire GIS visual without cropping and remove number-column assumptions.
cssp=Path('assets/styles.css')
css=cssp.read_text(encoding='utf-8')
css += r'''
/* V6 - framing and unnumbered topics */
.gis-frame{background:#e9f5fb;display:flex;flex-direction:column}
.gis-frame img{width:100%!important;height:auto!important;min-height:0!important;aspect-ratio:1600/980!important;object-fit:contain!important;object-position:center center!important;background:#e9f5fb}
.gis-frame figcaption{margin-top:auto}
.story-list article{grid-template-columns:1fr!important}
.command-flow article>span,.story-list article>span,.module-flow article>span{display:none!important}
.command-flow article strong{margin-top:0!important}
.module-flow article{grid-template-columns:1fr!important}
.datasheet-list b{font-size:8px!important;letter-spacing:.06em}
'''
cssp.write_text(css,encoding='utf-8')
print('V6 patch applied')
